"""
Feature extraction for the AI-Based Phishing and Cyber Fraud Detection System.

Two extractors are provided:
  - extract_url_features(url)      -> (feature_vector, reasons, raw_features_dict)
  - extract_message_features(text) -> (feature_vector, reasons, raw_features_dict)

Each extractor returns:
  feature_vector : list[float]  -- numeric features fed to the ML model
  reasons        : list[str]    -- human-readable rule hits, used for explainability
  raw_features   : dict         -- named features (useful for logging / debugging)
"""

import re
from urllib.parse import urlparse

# ---------------------------------------------------------------------------
# Shared vocabularies
# ---------------------------------------------------------------------------

SUSPICIOUS_TLDS = {
    "xyz", "top", "club", "info", "tk", "ml", "ga", "cf", "gq", "work",
    "click", "loan", "win", "review", "download", "zip", "country", "kim",
}

URL_SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", "is.gd", "buff.ly",
    "adf.ly", "cutt.ly", "rebrand.ly", "shorte.st", "bl.ink",
}

BRAND_IMPERSONATION_WORDS = {
    "paypal", "amazon", "apple", "microsoft", "netflix", "bank", "google",
    "facebook", "instagram", "whatsapp", "irs", "chase", "wellsfargo",
    "americanexpress", "dhl", "fedex", "flipkart", "sbi", "hdfc", "icici",
    "paytm",
}

URL_SENSITIVE_WORDS = {
    "login", "verify", "secure", "account", "update", "confirm", "signin",
    "webscr", "banking", "password", "unlock", "suspend", "billing",
    "invoice", "reset", "authenticate", "wallet",
}

URGENCY_WORDS = {
    "urgent", "immediately", "act now", "expire", "expires", "expiring",
    "suspend", "suspended", "verify now", "limited time", "last chance",
    "final notice", "action required", "within 24 hours", "asap",
}

REWARD_WORDS = {
    "winner", "congratulations", "claim", "free", "prize", "gift card",
    "lottery", "jackpot", "cashback", "reward", "bonus", "selected",
}

SENSITIVE_INFO_WORDS = {
    "otp", "password", "pin", "cvv", "ssn", "social security", "aadhar",
    "card number", "account number", "login details", "one time password",
    "bank details",
}

GENERIC_GREETINGS = {
    "dear customer", "dear user", "dear valued customer", "dear account holder",
    "dear sir/madam", "valued customer",
}

IP_REGEX = re.compile(
    r"^(25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)(\.(25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)){3}$"
)
URL_IN_TEXT_REGEX = re.compile(r"(https?://\S+|www\.\S+)", re.IGNORECASE)


# ---------------------------------------------------------------------------
# URL feature extraction
# ---------------------------------------------------------------------------

def extract_url_features(url: str):
    reasons = []
    raw = {}
    url_clean = url.strip()
    if not re.match(r"^[a-zA-Z]+://", url_clean):
        # No scheme provided; assume http for parsing purposes only.
        parse_target = "http://" + url_clean
    else:
        parse_target = url_clean

    try:
        parsed = urlparse(parse_target)
    except Exception:
        parsed = urlparse("http://invalid")

    host = parsed.netloc.lower()
    host_no_port = host.split(":")[0]
    path = parsed.path or ""
    query = parsed.query or ""
    full_lower = url_clean.lower()

    # --- basic length / structure features ---
    url_length = len(url_clean)
    raw["url_length"] = url_length
    if url_length > 75:
        reasons.append("Unusually long URL (%d characters)" % url_length)

    num_dots = host_no_port.count(".")
    raw["num_dots"] = num_dots
    num_subdomains = max(num_dots - 1, 0)
    if num_subdomains >= 3:
        reasons.append("Excessive number of subdomains (%d)" % num_subdomains)
    raw["num_subdomains"] = num_subdomains

    num_hyphens = host_no_port.count("-")
    raw["num_hyphens"] = num_hyphens
    if num_hyphens >= 2:
        reasons.append("Multiple hyphens in domain name, common in spoofed domains")

    num_digits = sum(c.isdigit() for c in host_no_port)
    raw["num_digits_in_host"] = num_digits
    if num_digits >= 4:
        reasons.append("Domain contains an unusually high number of digits")

    special_chars = sum(url_clean.count(c) for c in ["@", "%", "=", "&", "//"])
    raw["num_special_chars"] = special_chars

    has_at = "@" in url_clean
    raw["has_at_symbol"] = has_at
    if has_at:
        reasons.append("URL contains '@', which can be used to hide the real destination")

    is_ip = bool(IP_REGEX.match(host_no_port))
    raw["is_ip_address"] = is_ip
    if is_ip:
        reasons.append("Domain is a raw IP address instead of a name")

    has_https = parsed.scheme == "https"
    raw["has_https"] = has_https
    if not has_https:
        reasons.append("Connection is not secured with HTTPS")

    tld = host_no_port.split(".")[-1] if "." in host_no_port else ""
    raw["tld"] = tld
    suspicious_tld = tld in SUSPICIOUS_TLDS
    raw["suspicious_tld"] = suspicious_tld
    if suspicious_tld:
        reasons.append("Uses a top-level domain often associated with abuse (.%s)" % tld)

    is_shortener = host_no_port in URL_SHORTENERS
    raw["is_shortener"] = is_shortener
    if is_shortener:
        reasons.append("URL uses a link-shortening service, which can mask the real destination")

    sensitive_hits = [w for w in URL_SENSITIVE_WORDS if w in full_lower]
    raw["sensitive_word_hits"] = sensitive_hits
    if sensitive_hits:
        reasons.append("URL contains sensitive/action keywords: " + ", ".join(sorted(set(sensitive_hits))[:4]))

    brand_hits = [b for b in BRAND_IMPERSONATION_WORDS if b in host_no_port.replace("-", "")]
    # Flag only if brand appears in domain but domain is not an official-looking root
    raw["brand_mentions"] = brand_hits
    if brand_hits:
        reasons.append("Domain references a well-known brand (%s) — check for impersonation" % ", ".join(brand_hits))

    has_port = parsed.port is not None
    raw["has_port"] = has_port
    if has_port:
        reasons.append("URL explicitly specifies a non-standard port")

    path_length = len(path)
    raw["path_length"] = path_length

    num_query_params = len([p for p in query.split("&") if p]) if query else 0
    raw["num_query_params"] = num_query_params

    double_slash_redirect = "//" in (path + query)
    raw["double_slash_redirect"] = double_slash_redirect
    if double_slash_redirect:
        reasons.append("Contains a redirect-like double slash pattern in the path")

    if not reasons:
        reasons.append("No strong red flags detected in URL structure")

    feature_vector = [
        url_length,
        num_dots,
        num_subdomains,
        num_hyphens,
        num_digits,
        special_chars,
        int(has_at),
        int(is_ip),
        int(not has_https),
        int(suspicious_tld),
        int(is_shortener),
        len(sensitive_hits),
        len(brand_hits),
        int(has_port),
        path_length,
        num_query_params,
        int(double_slash_redirect),
    ]

    return feature_vector, reasons, raw


URL_FEATURE_NAMES = [
    "url_length", "num_dots", "num_subdomains", "num_hyphens", "num_digits",
    "num_special_chars", "has_at_symbol", "is_ip_address", "missing_https",
    "suspicious_tld", "is_shortener", "sensitive_word_count", "brand_mention_count",
    "has_port", "path_length", "num_query_params", "double_slash_redirect",
]


# ---------------------------------------------------------------------------
# Message / text feature extraction
# ---------------------------------------------------------------------------

def extract_message_features(text: str):
    reasons = []
    raw = {}
    text_clean = text.strip()
    lower = text_clean.lower()

    msg_length = len(text_clean)
    raw["msg_length"] = msg_length

    urls_found = URL_IN_TEXT_REGEX.findall(text_clean)
    raw["num_urls"] = len(urls_found)
    if urls_found:
        reasons.append("Message contains %d embedded link(s)" % len(urls_found))

    urgency_hits = [w for w in URGENCY_WORDS if w in lower]
    raw["urgency_hits"] = urgency_hits
    if urgency_hits:
        reasons.append("Uses urgency/pressure language: " + ", ".join(sorted(set(urgency_hits))[:4]))

    reward_hits = [w for w in REWARD_WORDS if w in lower]
    raw["reward_hits"] = reward_hits
    if reward_hits:
        reasons.append("Promises rewards/prizes: " + ", ".join(sorted(set(reward_hits))[:4]))

    sensitive_hits = [w for w in SENSITIVE_INFO_WORDS if w in lower]
    raw["sensitive_info_hits"] = sensitive_hits
    if sensitive_hits:
        reasons.append("Requests sensitive personal/financial information: " + ", ".join(sorted(set(sensitive_hits))[:4]))

    greeting_hits = [g for g in GENERIC_GREETINGS if g in lower]
    raw["generic_greeting"] = bool(greeting_hits)
    if greeting_hits:
        reasons.append("Uses a generic greeting instead of your actual name")

    num_exclamations = text_clean.count("!")
    raw["num_exclamations"] = num_exclamations
    if num_exclamations >= 3:
        reasons.append("Excessive use of exclamation marks")

    words = re.findall(r"[A-Za-z]+", text_clean)
    upper_words = [w for w in words if len(w) > 2 and w.isupper()]
    raw["num_uppercase_words"] = len(upper_words)
    if len(upper_words) >= 3:
        reasons.append("Excessive use of ALL CAPS words")

    money_mention = bool(re.search(r"[$₹€£]\s?\d|amount of|lottery|million|lakh|crore", lower))
    raw["money_mention"] = money_mention
    if money_mention:
        reasons.append("Mentions specific monetary amounts or winnings")

    brand_hits = [b for b in BRAND_IMPERSONATION_WORDS if b in lower]
    raw["brand_mentions"] = brand_hits
    if brand_hits:
        reasons.append("References a well-known brand: " + ", ".join(brand_hits))

    if not reasons:
        reasons.append("No strong red flags detected in message content")

    feature_vector = [
        msg_length,
        len(urls_found),
        len(urgency_hits),
        len(reward_hits),
        len(sensitive_hits),
        int(bool(greeting_hits)),
        num_exclamations,
        len(upper_words),
        int(money_mention),
        len(brand_hits),
    ]

    return feature_vector, reasons, raw


MESSAGE_FEATURE_NAMES = [
    "msg_length", "num_urls", "urgency_word_count", "reward_word_count",
    "sensitive_info_count", "generic_greeting", "num_exclamations",
    "num_uppercase_words", "money_mention", "brand_mention_count",
]
