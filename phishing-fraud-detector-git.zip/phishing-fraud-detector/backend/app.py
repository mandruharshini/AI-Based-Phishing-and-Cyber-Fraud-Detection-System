"""
Flask backend for the AI-Based Phishing and Cyber Fraud Detection System.

Endpoints:
  GET  /                      -> serves the frontend (frontend/index.html)
  POST /api/analyze/url       -> {"url": "..."}      -> classification result
  POST /api/analyze/message   -> {"message": "..."}  -> classification result
  GET  /api/health            -> simple health check
"""

import os
from flask import Flask, request, jsonify, send_from_directory

import model

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(os.path.dirname(BASE_DIR), "frontend")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")


@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


@app.route("/api/health")
def health():
    return jsonify({"status": "ok"})


@app.route("/api/analyze/url", methods=["POST"])
def analyze_url():
    data = request.get_json(silent=True) or {}
    url = data.get("url", "")
    try:
        result = model.predict_url(url)
        return jsonify(result)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": "Internal error", "detail": str(e)}), 500


@app.route("/api/analyze/message", methods=["POST"])
def analyze_message():
    data = request.get_json(silent=True) or {}
    message = data.get("message", "")
    try:
        result = model.predict_message(message)
        return jsonify(result)
    except ValueError as e:
        return jsonify({"error": str(e)}), 400
    except Exception as e:
        return jsonify({"error": "Internal error", "detail": str(e)}), 500


if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
