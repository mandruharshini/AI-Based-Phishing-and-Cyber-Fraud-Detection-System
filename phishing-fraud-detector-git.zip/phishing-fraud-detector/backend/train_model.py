"""
Trains the two RandomForest classifiers used by the app:
  - url_model.joblib      : classifies URLs as Safe / Suspicious / Fraud
  - message_model.joblib  : classifies text messages as Safe / Suspicious / Fraud

NOTE ON TRAINING DATA
----------------------
No internet access is available in this environment, so real-world labeled
datasets (e.g. PhishTank, UCI Phishing Websites, SMS Spam Collection) could
not be downloaded. Instead, this script generates a large synthetic dataset
by sampling feature vectors from distributions that mirror realistic
"safe" vs "suspicious" vs "fraud" behaviour (based on the same rules used
in feature_extraction.py), then adds label noise so the model has to learn
genuine decision boundaries rather than memorizing a lookup table.

For production use, replace `generate_url_dataset` / `generate_message_dataset`
with real labeled data (see README.md for recommended public datasets), and
re-run this script. The rest of the pipeline (feature extraction, Flask API,
frontend) does not need to change.
"""

import os
import random
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import joblib

from feature_extraction import URL_FEATURE_NAMES, MESSAGE_FEATURE_NAMES

RANDOM_SEED = 42
random.seed(RANDOM_SEED)
np.random.seed(RANDOM_SEED)

MODELS_DIR = os.path.join(os.path.dirname(__file__), "models")
os.makedirs(MODELS_DIR, exist_ok=True)

LABELS = ["Safe", "Suspicious", "Fraud"]


def _bucket(score, low, high):
    """Turn a continuous risk score into a class index with soft boundaries."""
    if score < low:
        return 0
    if score < high:
        return 1
    return 2


def generate_url_dataset(n=6000):
    """
    Feature order (see URL_FEATURE_NAMES):
    url_length, num_dots, num_subdomains, num_hyphens, num_digits,
    num_special_chars, has_at_symbol, is_ip_address, missing_https,
    suspicious_tld, is_shortener, sensitive_word_count, brand_mention_count,
    has_port, path_length, num_query_params, double_slash_redirect
    """
    X, y = [], []
    for _ in range(n):
        # Decide a "ground truth" archetype to keep the distribution realistic.
        archetype = random.choices(["safe", "suspicious", "fraud"], weights=[0.55, 0.25, 0.20])[0]

        if archetype == "safe":
            url_length = np.random.randint(15, 45)
            num_dots = np.random.choice([1, 2], p=[0.8, 0.2])
            num_hyphens = np.random.choice([0, 1], p=[0.85, 0.15])
            num_digits = np.random.randint(0, 2)
            special = np.random.randint(0, 2)
            has_at = 0
            is_ip = 0
            missing_https = np.random.choice([0, 1], p=[0.9, 0.1])
            sus_tld = np.random.choice([0, 1], p=[0.95, 0.05])
            shortener = 0
            sensitive = np.random.randint(0, 1)
            brand = 0
            has_port = 0
            path_len = np.random.randint(0, 20)
            n_query = np.random.randint(0, 2)
            dslash = 0
        elif archetype == "suspicious":
            url_length = np.random.randint(35, 90)
            num_dots = np.random.choice([2, 3], p=[0.6, 0.4])
            num_hyphens = np.random.choice([1, 2], p=[0.5, 0.5])
            num_digits = np.random.randint(1, 5)
            special = np.random.randint(1, 4)
            has_at = np.random.choice([0, 1], p=[0.85, 0.15])
            is_ip = np.random.choice([0, 1], p=[0.9, 0.1])
            missing_https = np.random.choice([0, 1], p=[0.5, 0.5])
            sus_tld = np.random.choice([0, 1], p=[0.6, 0.4])
            shortener = np.random.choice([0, 1], p=[0.7, 0.3])
            sensitive = np.random.randint(0, 3)
            brand = np.random.choice([0, 1], p=[0.6, 0.4])
            has_port = np.random.choice([0, 1], p=[0.9, 0.1])
            path_len = np.random.randint(5, 40)
            n_query = np.random.randint(0, 4)
            dslash = np.random.choice([0, 1], p=[0.8, 0.2])
        else:  # fraud
            url_length = np.random.randint(55, 160)
            num_dots = np.random.choice([3, 4, 5], p=[0.4, 0.4, 0.2])
            num_hyphens = np.random.randint(2, 6)
            num_digits = np.random.randint(3, 10)
            special = np.random.randint(3, 8)
            has_at = np.random.choice([0, 1], p=[0.5, 0.5])
            is_ip = np.random.choice([0, 1], p=[0.6, 0.4])
            missing_https = np.random.choice([0, 1], p=[0.3, 0.7])
            sus_tld = np.random.choice([0, 1], p=[0.3, 0.7])
            shortener = np.random.choice([0, 1], p=[0.4, 0.6])
            sensitive = np.random.randint(2, 6)
            brand = np.random.choice([0, 1], p=[0.3, 0.7])
            has_port = np.random.choice([0, 1], p=[0.8, 0.2])
            path_len = np.random.randint(20, 80)
            n_query = np.random.randint(2, 8)
            dslash = np.random.choice([0, 1], p=[0.5, 0.5])

        num_subdomains = max(num_dots - 1, 0)

        features = [
            url_length, num_dots, num_subdomains, num_hyphens, num_digits,
            special, has_at, is_ip, missing_https, sus_tld, shortener,
            sensitive, brand, has_port, path_len, n_query, dslash,
        ]
        label = {"safe": 0, "suspicious": 1, "fraud": 2}[archetype]

        # 6% label noise to avoid a trivially separable dataset
        if random.random() < 0.06:
            label = random.choice([0, 1, 2])

        X.append(features)
        y.append(label)

    return np.array(X, dtype=float), np.array(y, dtype=int)


def generate_message_dataset(n=6000):
    """
    Feature order (see MESSAGE_FEATURE_NAMES):
    msg_length, num_urls, urgency_word_count, reward_word_count,
    sensitive_info_count, generic_greeting, num_exclamations,
    num_uppercase_words, money_mention, brand_mention_count
    """
    X, y = [], []
    for _ in range(n):
        archetype = random.choices(["safe", "suspicious", "fraud"], weights=[0.55, 0.25, 0.20])[0]

        if archetype == "safe":
            msg_length = np.random.randint(20, 200)
            num_urls = np.random.choice([0, 1], p=[0.85, 0.15])
            urgency = np.random.randint(0, 1)
            reward = np.random.randint(0, 1)
            sensitive = 0
            greeting = np.random.choice([0, 1], p=[0.9, 0.1])
            excls = np.random.randint(0, 2)
            upper = np.random.randint(0, 2)
            money = np.random.choice([0, 1], p=[0.9, 0.1])
            brand = np.random.choice([0, 1], p=[0.8, 0.2])
        elif archetype == "suspicious":
            msg_length = np.random.randint(40, 300)
            num_urls = np.random.choice([0, 1, 2], p=[0.3, 0.5, 0.2])
            urgency = np.random.randint(0, 3)
            reward = np.random.randint(0, 3)
            sensitive = np.random.randint(0, 2)
            greeting = np.random.choice([0, 1], p=[0.6, 0.4])
            excls = np.random.randint(0, 4)
            upper = np.random.randint(0, 4)
            money = np.random.choice([0, 1], p=[0.6, 0.4])
            brand = np.random.choice([0, 1], p=[0.5, 0.5])
        else:  # fraud
            msg_length = np.random.randint(30, 400)
            num_urls = np.random.choice([1, 2, 3], p=[0.4, 0.4, 0.2])
            urgency = np.random.randint(2, 6)
            reward = np.random.randint(1, 5)
            sensitive = np.random.randint(2, 5)
            greeting = np.random.choice([0, 1], p=[0.3, 0.7])
            excls = np.random.randint(2, 8)
            upper = np.random.randint(2, 8)
            money = np.random.choice([0, 1], p=[0.25, 0.75])
            brand = np.random.choice([0, 1], p=[0.3, 0.7])

        features = [
            msg_length, num_urls, urgency, reward, sensitive, greeting,
            excls, upper, money, brand,
        ]
        label = {"safe": 0, "suspicious": 1, "fraud": 2}[archetype]

        if random.random() < 0.06:
            label = random.choice([0, 1, 2])

        X.append(features)
        y.append(label)

    return np.array(X, dtype=float), np.array(y, dtype=int)


def train_and_save(X, y, feature_names, out_name, label_names=LABELS):
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=RANDOM_SEED, stratify=y
    )
    clf = RandomForestClassifier(
        n_estimators=300,
        max_depth=12,
        min_samples_leaf=3,
        random_state=RANDOM_SEED,
        class_weight="balanced",
    )
    clf.fit(X_train, y_train)
    preds = clf.predict(X_test)
    report = classification_report(y_test, preds, target_names=label_names, zero_division=0)
    print(f"\n=== {out_name} evaluation ===")
    print(report)

    importances = sorted(
        zip(feature_names, clf.feature_importances_), key=lambda t: -t[1]
    )
    print("Top features:")
    for name, imp in importances[:6]:
        print(f"  {name}: {imp:.3f}")

    path = os.path.join(MODELS_DIR, out_name)
    joblib.dump({"model": clf, "feature_names": feature_names, "labels": label_names}, path)
    print(f"Saved model to {path}")
    return clf


if __name__ == "__main__":
    print("Generating synthetic URL dataset...")
    X_url, y_url = generate_url_dataset()
    train_and_save(X_url, y_url, URL_FEATURE_NAMES, "url_model.joblib")

    print("\nGenerating synthetic message dataset...")
    X_msg, y_msg = generate_message_dataset()
    train_and_save(X_msg, y_msg, MESSAGE_FEATURE_NAMES, "message_model.joblib")

    print("\nDone. Models saved in backend/models/")
