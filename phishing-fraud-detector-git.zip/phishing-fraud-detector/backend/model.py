"""
Loads the trained URL and message models and exposes a single `predict`
function that combines the ML model's class probabilities with the
rule-based reasons from feature_extraction.py.
"""

import os
import joblib
import numpy as np

from feature_extraction import extract_url_features, extract_message_features

MODELS_DIR = os.path.join(os.path.dirname(__file__), "models")

_url_bundle = None
_message_bundle = None


def _load_bundle(name):
    path = os.path.join(MODELS_DIR, name)
    if not os.path.exists(path):
        raise FileNotFoundError(
            f"Model file '{name}' not found in {MODELS_DIR}. "
            f"Run `python train_model.py` first."
        )
    return joblib.load(path)


def _get_url_bundle():
    global _url_bundle
    if _url_bundle is None:
        _url_bundle = _load_bundle("url_model.joblib")
    return _url_bundle


def _get_message_bundle():
    global _message_bundle
    if _message_bundle is None:
        _message_bundle = _load_bundle("message_model.joblib")
    return _message_bundle


def _predict_common(bundle, feature_vector, reasons):
    clf = bundle["model"]
    labels = bundle["labels"]  # ["Safe", "Suspicious", "Fraud"]

    proba = clf.predict_proba([feature_vector])[0]
    pred_idx = int(np.argmax(proba))
    classification = labels[pred_idx]

    # Risk score: 0 = totally safe, 100 = certain fraud.
    # Weighted combination of class probabilities so "Suspicious" confidence
    # also nudges the score up, not just "Fraud" confidence.
    weights = np.array([0, 50, 100])[: len(proba)]
    risk_score = float(np.dot(proba, weights))
    risk_score = round(min(max(risk_score, 0), 100), 1)

    confidence = round(float(proba[pred_idx]) * 100, 1)

    return {
        "classification": classification,
        "risk_score": risk_score,
        "confidence": confidence,
        "class_probabilities": {
            label: round(float(p) * 100, 1) for label, p in zip(labels, proba)
        },
        "reasons": reasons,
    }


def predict_url(url: str):
    if not url or not url.strip():
        raise ValueError("URL must not be empty")
    bundle = _get_url_bundle()
    feature_vector, reasons, raw_features = extract_url_features(url)
    result = _predict_common(bundle, feature_vector, reasons)
    result["input_type"] = "url"
    result["input"] = url
    result["raw_features"] = raw_features
    return result


def predict_message(message: str):
    if not message or not message.strip():
        raise ValueError("Message must not be empty")
    bundle = _get_message_bundle()
    feature_vector, reasons, raw_features = extract_message_features(message)
    result = _predict_common(bundle, feature_vector, reasons)
    result["input_type"] = "message"
    result["input"] = message
    result["raw_features"] = raw_features
    return result
